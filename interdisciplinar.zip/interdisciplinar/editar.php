<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Editar</title>
		<meta charset="utf-8">
	</head>
	<body>
		<fieldset>
			<legend>Perdão não é possivel editar</legend>
				<a href="index.php">Clique aqui para retornar</a>
		</fieldset>
	</body>
</html>